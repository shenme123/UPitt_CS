/*
	Exercise1.java

	This program fills an array of random size with random ints.
	Then finds and reports the smallest value and the largest value in the array
	along with the index where the min or max was located
*/


import java.io.*;
import java.util.Random;

public class Exercise1
{
	public static void main( String args[] )
	{
		// declare an array reference - JUST a reference

		// initialize the this array to have a random dimension between 10 and 25 inclusive

		// loop: fill the array with random values between 0 and 100 inclusive

		// loop: find and report the min

		// loop: find and report the max
	}

}
