
package mb;

public class Account implements java.io.Serializable{
    private String userID;
    private String password;
    
    public Account(){}

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
}
