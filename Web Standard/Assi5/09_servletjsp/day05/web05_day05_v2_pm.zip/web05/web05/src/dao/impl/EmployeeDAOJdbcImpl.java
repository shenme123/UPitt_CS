package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;
import dao.EmployeeDAO;
import entity.Employee;

public class EmployeeDAOJdbcImpl implements EmployeeDAO{

	public List<Employee> findAll() throws Exception {
		List<Employee> employees = 
			new ArrayList<Employee>();
		Connection conn = null;
		try{
			conn = DBUtil.getConnection();
			Statement stat = conn.createStatement();
			ResultSet rst = stat.executeQuery(
					"select * from t_emp");
			while(rst.next()){
				Employee e = new Employee();
				e.setId(rst.getInt("id"));
				e.setName(rst.getString("name"));
				e.setSalary(rst.getDouble("salary"));
				e.setAge(rst.getInt("age"));
				employees.add(e);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			DBUtil.close(conn);
		}
		return employees;
	}

	public void save(Employee e) throws Exception {
		Connection conn = null;
		try{
			conn = DBUtil.getConnection();
			PreparedStatement stat = 
				conn.prepareStatement(
						"insert into t_emp(name,salary,age) " +
						"values(?,?,?)");
			stat.setString(1, e.getName());
			stat.setDouble(2, e.getSalary());
			stat.setInt(3, e.getAge());
			stat.executeUpdate();
		}catch(Exception e1){
			e1.printStackTrace();
			throw e1;
		}finally{
			DBUtil.close(conn);
		}
		
	}

	public void delete(int id) throws Exception {
		// TODO Auto-generated method stub
		
	}

	public Employee findById(int id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public void modify(Employee e) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
