package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Factory;
import dao.EmployeeDAO;
import entity.Employee;

public class ActionServlet extends HttpServlet {

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		String action = uri.substring(uri.lastIndexOf("/"),
				uri.lastIndexOf("."));
		if(action.equals("/list")){
			String ip = request.getRemoteAddr();
			//��ѯ���ݿ�
			try {
				EmployeeDAO dao = 
					(EmployeeDAO)Factory.getInstance("EmployeeDAO");
				List<Employee> employees = 
					dao.findAll();
				//����jsp(ʹ��ת��)
				//step1 ������
				request.setAttribute("employees", employees);
				//step2 ���ת����
				RequestDispatcher rd = 
					request.getRequestDispatcher("emp_list3.jsp");
				//step3 ת��
				rd.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(action.equals("/add")){
			String name = request.getParameter("name");
			//������֤(����������֤)
			if(name == null ||name.equals("")){
				//��ʾ�û����û�������Ϊ��
				request.setAttribute(
						"add_error", "�û�������Ϊ��");
				request.getRequestDispatcher("addEmp.jsp")
				.forward(request, response);
				return;
			}
			double salary = Double.parseDouble(
					request.getParameter("salary"));
			int age = Integer.parseInt(request.getParameter("age"));
				EmployeeDAO dao = 
					(EmployeeDAO)Factory.getInstance("EmployeeDAO");
			try{	
				dao.save(new Employee(name,salary,age));
				response.sendRedirect("list.do");
			}catch(Exception e){
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(action.equals("/del")){
//			���Ҫɾ�����û���id��
			int id = Integer.parseInt(request.getParameter("id"));
			//�������ݿ�
			try{
				EmployeeDAO dao = 
				(EmployeeDAO)Factory.getInstance("EmployeeDAO");
				dao.delete(id);
				response.sendRedirect("list.do");
			}catch(Exception e){
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(action.equals("/load")){
			int id = Integer.parseInt(request.getParameter("id"));
			try {
				EmployeeDAO dao = 
					(EmployeeDAO)Factory.getInstance("EmployeeDAO");
				Employee e = dao.findById(id);
				//ʹ��ת��
				request.setAttribute("e", e);
				request.getRequestDispatcher("updateEmp.jsp")
				.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(action.equals("/modify")){
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			double salary = Double.parseDouble(
					request.getParameter("salary"));
			int age = Integer.parseInt(request.getParameter("age"));
			try {
				EmployeeDAO dao = 
					(EmployeeDAO)Factory.getInstance("EmployeeDAO");
				Employee e = new Employee(name,salary,age);
				e.setId(id);
				dao.modify(e);
				response.sendRedirect("list.do");
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		}
		
	}

}
