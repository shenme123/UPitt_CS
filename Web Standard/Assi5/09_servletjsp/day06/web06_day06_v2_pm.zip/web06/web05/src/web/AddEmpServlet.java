package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Factory;

import dao.EmployeeDAO;
import entity.Employee;

public class AddEmpServlet extends HttpServlet{
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		double salary = Double.parseDouble(
				request.getParameter("salary"));
		int age = Integer.parseInt(request.getParameter("age"));
			EmployeeDAO dao = 
				(EmployeeDAO)Factory.getInstance("EmployeeDAO");
		try{	
			dao.save(new Employee(name,salary,age));
			response.sendRedirect("list");
		}catch(Exception e){
			e.printStackTrace();
			out.println("ϵͳ�쳣���Ժ�����");
		}
		out.close();
	}

}
