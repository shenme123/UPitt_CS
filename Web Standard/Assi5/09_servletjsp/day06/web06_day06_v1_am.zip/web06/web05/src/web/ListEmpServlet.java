package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Factory;
import dao.EmployeeDAO;
import entity.Employee;

public class ListEmpServlet extends HttpServlet{
	//service����Ҫ��override HttpServlet��ͬ��������
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException{
		String ip = request.getRemoteAddr();
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		//��ѯ���ݿ�
		try {
			EmployeeDAO dao = 
				(EmployeeDAO)Factory.getInstance("EmployeeDAO");
			List<Employee> employees = 
				dao.findAll();
			//����jsp(ʹ��ת��)
			//step1 ������
			request.setAttribute("employees", employees);
			//step2 ���ת����
			RequestDispatcher rd = 
				request.getRequestDispatcher("emp_list3.jsp");
			//step3 ת��
			out.println("����ת����");
			rd.forward(request, response);
			System.out.println("ת��...");
		} catch (Exception e) {
			e.printStackTrace();
			out.println("ϵͳ�쳣���Ժ�����");
		}
		out.close();
	}
}
