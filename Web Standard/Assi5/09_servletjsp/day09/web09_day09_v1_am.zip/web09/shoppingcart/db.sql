create table t_computer(
				id int primary key auto_increment,
				model varchar(50),
				picName varchar(100),
				prodDesc varchar(255),
				price double
			);
			insert into t_computer(model,picName,prodDesc,price) 
			values('x200','x200.jpg','�Լ۱����',1000);
			insert into t_computer(model,picName,prodDesc,price) 
			values('x500','x500.jpg','�ʺϰ칫��Ҳ����',2000);
			insert into t_computer(model,picName,prodDesc,price) 
			values('x600','x600.jpg','�ܹ󣬻���',3000);
