package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;
import entity.Computer;

public class ComputerDAO {
	public List<Computer> findAll() throws Exception{
		List<Computer> computers = 
			new ArrayList<Computer>();
		Connection conn = null;
		try{
			conn = DBUtil.getConnection();
			Statement stat = conn.createStatement();
			ResultSet rst = stat.executeQuery(
					"select * from t_computer");
			while(rst.next()){
				Computer c = new Computer();
				c.setId(rst.getInt("id"));
				c.setModel(rst.getString("model"));
				c.setPicName(rst.getString("picName"));
				c.setProdDesc(rst.getString("prodDesc"));
				c.setPrice(rst.getDouble("price"));
				computers.add(c);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			DBUtil.close(conn);
		}
		return computers;
	}

	public Computer findById(int id) throws Exception {
		Computer c = null;
		Connection conn = null;
		try{
			conn = DBUtil.getConnection();
			Statement stat = conn.createStatement();
			ResultSet rst = stat.executeQuery(
					"select * from t_computer where id=" + id);
			while(rst.next()){
				 c = new Computer();
				c.setId(rst.getInt("id"));
				c.setModel(rst.getString("model"));
				c.setPicName(rst.getString("picName"));
				c.setProdDesc(rst.getString("prodDesc"));
				c.setPrice(rst.getDouble("price"));
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			DBUtil.close(conn);
		}
		return c;
	}
}
