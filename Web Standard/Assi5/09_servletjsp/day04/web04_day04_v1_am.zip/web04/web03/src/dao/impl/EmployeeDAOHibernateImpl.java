package dao.impl;

import java.util.List;

import dao.EmployeeDAO;
import entity.Employee;

public class EmployeeDAOHibernateImpl implements EmployeeDAO{

	public List<Employee> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
