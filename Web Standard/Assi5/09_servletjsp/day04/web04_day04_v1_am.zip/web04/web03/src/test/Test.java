package test;

import dao.EmployeeDAO;
import dao.impl.EmployeeDAOJdbcImpl;

public class Test {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		EmployeeDAO dao = 
			new EmployeeDAOJdbcImpl();
		System.out.println(dao.findAll().size());

	}

}
