package dao;

import java.util.List;

import entity.Employee;
/**
 * DAO�ӿ�
 *
 */
public interface EmployeeDAO {
	public List<Employee> findAll() throws Exception;
	
	
	
	
	
}
