package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * ��config.properites�����ļ��Ĺ���
 */
public class ConfigUtil {
	private static Properties props = 
		new Properties();
	static{
		InputStream ips = ConfigUtil.class.getClassLoader()
		.getResourceAsStream("util/config.properties");
		try {
			props.load(ips);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
