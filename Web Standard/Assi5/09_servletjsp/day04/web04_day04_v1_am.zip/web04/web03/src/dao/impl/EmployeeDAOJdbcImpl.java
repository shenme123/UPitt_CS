package dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import util.DBUtil;
import dao.EmployeeDAO;
import entity.Employee;

public class EmployeeDAOJdbcImpl implements EmployeeDAO{

	public List<Employee> findAll() throws Exception {
		List<Employee> employees = 
			new ArrayList<Employee>();
		Connection conn = null;
		try{
			conn = DBUtil.getConnection();
			Statement stat = conn.createStatement();
			ResultSet rst = stat.executeQuery(
					"select * from t_emp");
			while(rst.next()){
				Employee e = new Employee();
				e.setId(rst.getInt("id"));
				e.setName(rst.getString("name"));
				e.setSalary(rst.getDouble("salary"));
				e.setAge(rst.getInt("age"));
				employees.add(e);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			DBUtil.close(conn);
		}
		return employees;
	}

}
