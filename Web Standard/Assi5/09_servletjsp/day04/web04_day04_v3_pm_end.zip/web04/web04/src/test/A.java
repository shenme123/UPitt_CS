package test;

public class A {
	public void f1(){
		System.out.println("f1...");
		f2();
	}
	//���ӷ���
	public void f2(){
		
	}
}
