package test;

public class B extends A{

	@Override
	public void f2() {
		System.out.println("B's f2...");
	}
	
}
