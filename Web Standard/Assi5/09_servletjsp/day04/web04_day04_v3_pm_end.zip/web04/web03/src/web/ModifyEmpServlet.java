package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.DBUtil;

public class ModifyEmpServlet extends HttpServlet{
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		double salary = Double.parseDouble(
				request.getParameter("salary"));
		int age = Integer.parseInt(request.getParameter("age"));
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement stat = 
				conn.prepareStatement("update t_emp set " +
						"name=?,salary=?,age=? where id=?");
			stat.setString(1, name);
			stat.setDouble(2, salary);
			stat.setInt(3, age);
			stat.setInt(4, id);
			stat.executeUpdate();
			response.sendRedirect("list");
		} catch (Exception e) {
			e.printStackTrace();
			out.println("ϵͳ�쳣���Ժ�����");
		}finally{
			DBUtil.close(conn);
		}
		out.close();
	}

}
