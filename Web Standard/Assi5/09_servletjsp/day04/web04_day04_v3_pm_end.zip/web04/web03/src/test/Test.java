package test;

import dao.EmployeeDAO;
import dao.impl.EmployeeDAOJdbcImpl;
import entity.Employee;

public class Test {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		EmployeeDAO dao = 
			new EmployeeDAOJdbcImpl();
		//System.out.println(dao.findAll().size());
		dao.save(new Employee("abc123",2000,22));

	}

}
