package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DelEmpServlet extends HttpServlet{
	
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException{
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		//���Ҫɾ�����û���id��
		int id = Integer.parseInt(request.getParameter("id"));
		//�������ݿ�
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/jd1206db?" +
					"useUnicode=true&characterEncoding=utf8",
					"root","1234");
			Statement stat = conn.createStatement();
			String sql = "delete from t_emp where id=" + id;
			stat.executeUpdate(sql);
			//out.println("ɾ���Ѿ�ִ�����");
			response.sendRedirect("list");
			//response.sendRedirect("http://bbs.tarena.com.cn");
			//System.out.println("�ض���֮��...");
		}catch(Exception e){
			e.printStackTrace();
			out.println("ϵͳ�쳣���Ժ�����");
		}finally{
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		out.close();
	}

}
