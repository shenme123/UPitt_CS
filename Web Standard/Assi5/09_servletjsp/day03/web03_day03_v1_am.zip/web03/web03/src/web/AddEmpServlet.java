package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddEmpServlet extends HttpServlet{
	public void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException{
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		double salary = Double.parseDouble(
				request.getParameter("salary"));
		int age = Integer.parseInt(request.getParameter("age"));
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/jd1206db",
					"root","1234");
			PreparedStatement stat = 
				conn.prepareStatement(
						"insert into t_emp(name,salary,age) " +
						"values(?,?,?)");
			stat.setString(1, name);
			stat.setDouble(2, salary);
			stat.setInt(3, age);
			stat.executeUpdate();
			//out.println("���ӳɹ�<br/>");
			//out.println("<a href='list'>�鿴Ա���б�</a>");
			//�ض���
			response.sendRedirect("list");
		}catch(Exception e){
			e.printStackTrace();
			out.println("ϵͳ�쳣���Ժ�����");
		}finally{
			if(conn != null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		out.close();
	}

}
