package test;

import java.util.List;

import dao.ComputerDAO;

import entity.Computer;

public class Test {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ComputerDAO dao = 
			new ComputerDAO();
		List<Computer> computers = 
			dao.findAll();
		System.out.println(computers.size());
	}

}
