package web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.CookieUtil;

import bean.Cart;
import bean.CartItem;
import dao.ComputerDAO;
import entity.Computer;

public class ShoppingCartServlet extends HttpServlet {

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String uri = request.getRequestURI();
		String path = uri.substring(uri.lastIndexOf("/"),
				uri.lastIndexOf("."));
		if(path.equals("/list")){
			ComputerDAO dao = 
				new ComputerDAO();
			try {
				List<Computer> computers = 
					dao.findAll();
				request.setAttribute("computers", computers);
				request.getRequestDispatcher("computer_list.jsp")
				.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
			
		}else if(path.equals("/buy")){
			long id = Long.parseLong(request.getParameter("id"));
			ComputerDAO dao = new ComputerDAO();
			try {
				Computer c = dao.findById(id);
				CartItem item = new CartItem();
				item.setQty(1);
				item.setC(c);
				HttpSession session = 
					request.getSession();
				Cart cart = (Cart) session.getAttribute("cart");
				if(cart == null){
					//���cart==null,˵�������û���һ�ε������
					//��Ҫ����һ��cart���󣬲��Ҵ�ŵ�session�����ϡ�
					cart = new Cart();
					//�п����û�֮ǰ�Ѿ������һЩ��Ʒ����Щ��Ʒ
					//��Ϣ�Ѿ���cookie����ʽ�������˿ͻ��ˣ���Ҫ��
					//�ָ�
					String content = CookieUtil.findCookie("cart",request);
					cart.load(content);
					session.setAttribute("cart", cart);
				}
				boolean flag = cart.add(item);
				if(!flag){
					//����������Ʒ������ʾ�û��Ѿ�����
					request.setAttribute("buy_error" + id, 
							"�Ѿ����������Ʒ");
					//list.do     computer_list.jsp
					request.getRequestDispatcher("list.do")
					.forward(request, response);
				}else{
					//����ɹ�����Ҫ�����ﳵ�е���Ʒ���ݵ��ͻ���
					CookieUtil.addCookie("cart", cart.store(), response);
					response.sendRedirect("list.do");
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(path.equals("/clear")){
			HttpSession session = 
				request.getSession();
			Cart cart = (Cart)session.getAttribute("cart");
			cart.clear();
			CookieUtil.deleteCookie("cart", response);
			response.sendRedirect("cart.jsp");
		}else if(path.equals("/del")){
			long id = Long.parseLong(request.getParameter("id"));
			HttpSession session = 
				request.getSession();
			Cart cart = (Cart)session.getAttribute("cart");
			cart.delete(id);
			CookieUtil.addCookie("cart", cart.store(), response);
			response.sendRedirect("cart.jsp");
		}else if(path.equals("/modify")){
			long id = Long.parseLong(request.getParameter("id"));
			int qty = Integer.parseInt(request.getParameter("qty"));
			HttpSession session = 
				request.getSession();
			Cart cart = (Cart)session.getAttribute("cart");
			cart.modify(id, qty);
			CookieUtil.addCookie("cart", cart.store(), response);
			response.sendRedirect("cart.jsp");
		}
		
	}

}
