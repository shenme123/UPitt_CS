package util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * cookie���ߣ���װ��cookie�����ӡ�
 * ��ѯ��ɾ��������
 * @author teacher
 *
 */
public class CookieUtil {
	private static String path = "/shoppingcart2";
	private static int age = 365 * 24 * 3600;
	/**
	 * ����cookie
	 * @param name
	 * @param value
	 * @param response
	 * @param maxAge
	 * @throws UnsupportedEncodingException
	 */
	public static void addCookie(String name,
	 		String value,HttpServletResponse response,
	 		int maxAge) throws UnsupportedEncodingException{
		Cookie cookie = new Cookie(
				name,URLEncoder.encode(value,"utf-8"));
		cookie.setMaxAge(age);
		cookie.setPath(path);
		response.addCookie(cookie);
	}
	
	/**
	 * ����cookie
	 * @param name
	 * @param value
	 * @param response
	 * @throws UnsupportedEncodingException
	 */
	public static void addCookie(String name,
	 		String value,HttpServletResponse response) throws UnsupportedEncodingException{
		addCookie(name,value,response,age);
	}
	
	/**
	 * ����cookie�����ַ�����ֵ��
	 * ����Ҳ������򷵻�null��
	 * @param name
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String findCookie(
	 		String name,HttpServletRequest request) throws UnsupportedEncodingException{
		String value = null;
		Cookie[] cookies = request.getCookies();
		if(cookies != null){
			for(int i=0;i<cookies.length;i++){
				Cookie cookie = cookies[i];
				if(cookie.getName().equals(name)){
					value = URLDecoder.decode(
							cookie.getValue(),"utf-8");
				}
			}
		}
		return value;
	}
	
	/**
	 * ɾ��cookie
	 * @param name
	 * @param response
	 */
	public static void deleteCookie(
	 		String name,HttpServletResponse response){
		Cookie cookie = new Cookie(name,"");
		cookie.setMaxAge(0);
		cookie.setPath(path);
		response.addCookie(cookie);
	}
}
