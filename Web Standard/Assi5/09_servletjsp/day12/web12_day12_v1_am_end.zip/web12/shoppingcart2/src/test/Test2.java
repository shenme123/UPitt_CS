package test;

import java.util.List;

import bean.Cart;
import bean.CartItem;

public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Cart cart = new Cart();
//		Computer c = new Computer("x600","600.jpg","good",3000);
//		c.setId(1);
//		CartItem item = new CartItem();
//		item.setC(c);
//		item.setQty(3);
//		cart.add(item);
//		
//		Computer c2 = new Computer("x500","500.jpg","good",2000);
//		c2.setId(2);
//		CartItem item2 = new CartItem();
//		item2.setC(c2);
//		item2.setQty(8);
//		cart.add(item2);
//		String content = cart.store();
//		System.out.println(content);
		
		String content = "3,8;2,10";
		Cart cart = new Cart();
		cart.load(content);
		List<CartItem> items = cart.list();
		System.out.println(items.size());
	}

}
