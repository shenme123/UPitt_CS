

create table t_computer2(
id bigint primary key auto_increment,
model varchar(50),
prodDesc text,
pic varchar(255),
price double(8,2));

insert into t_computer2(model,prodDesc,pic,price) values('x200','����','x200.jpg',2000);
insert into t_computer2(model,prodDesc,pic,price) values('x500','����','x500.jpg',3000);
insert into t_computer2(model,prodDesc,pic,price) values('x600','����','x600.jpg',4000);