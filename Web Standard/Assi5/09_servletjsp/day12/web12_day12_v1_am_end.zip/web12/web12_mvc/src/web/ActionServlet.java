package web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BMIService;

public class ActionServlet extends HttpServlet {

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//����������Դ·������������ú��ʵ�model����������
		String uri = request.getRequestURI();
		String action = uri.substring(uri.lastIndexOf("/"),
				uri.lastIndexOf("."));
		if(action.equals("/bmi")){
			BMIService service = new BMIService();
			String gender = request.getParameter("gender");
			double height = Double.parseDouble(request.getParameter("height"));
			double weight = Double.parseDouble(request.getParameter("weight"));
			String status = service.quoto(height, weight, gender);
			//ѡ����ʵ���ͼ��չ�ֽ��
			request.setAttribute("status", status);
			request.getRequestDispatcher("view2.jsp")
			.forward(request, response);
		}
		
		
	}

}
