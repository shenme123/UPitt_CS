Wentao Jiang, wej10

All J, Q, K are shown as 10.(Running out of time)