To execute Checker.java. Compile it then enter the following at the command line:

$ java Checker puzzle*.txt